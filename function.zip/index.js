const express = require('express');
const serverless = require('serverless-http');
const dns = require('dns').promises;
const mysql = require('mysql2/promise');
const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');

const app = express();

// Use environment variables or defaults as needed.
const REGION = process.env.REGION || 'us-west-1';
const SECRET_NAME = process.env.SECRET_NAME || 'rds-db-credentials';

// Function to fetch database credentials from Secrets Manager.
async function getSecret() {
  const client = new SecretsManagerClient({ region: REGION });
  const command = new GetSecretValueCommand({ SecretId: SECRET_NAME });
  const response = await client.send(command);
  return JSON.parse(response.SecretString);
}

// Function to create a connection to your RDS using mysql2.
async function getConnection() {
  const creds = await getSecret();
  return mysql.createConnection({
    host: creds.host,
    user: creds.username,
    password: creds.password,
    database: creds.dbname,
    port: creds.port || 3306
  });
}

// Express route: Connects to RDS, performs a DNS lookup, and returns an HTML page.
app.get('/', async (req, res) => {
  try {
    const conn = await getConnection();
    const [rows] = await conn.query('SELECT NOW() AS now');
    await conn.end();

    const dnsResult = await dns.lookup('google.com');

    // Build a styled HTML page.
    const html = `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <title>Connection Status</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              background-color: #f7f7f7;
              margin: 0;
              padding: 0;
              display: flex;
              align-items: center;
              justify-content: center;
              min-height: 100vh;
            }
            .container {
              background: #fff;
              padding: 20px 30px;
              box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
              border-radius: 8px;
              max-width: 600px;
              width: 90%;
            }
            h1 {
              text-align: center;
              color: #2c3e50;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th, td {
              padding: 12px 15px;
              text-align: left;
              border-bottom: 1px solid #ddd;
            }
            th {
              background-color: #ecf0f1;
            }
            .error {
              color: #e74c3c;
              font-weight: bold;
              text-align: center;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Connection Status</h1>
            <table>
              <tr>
                <th>Message</th>
                <td>Connected to private RDS and Internet</td>
              </tr>
              <tr>
                <th>Database Time</th>
                <td>${rows[0].now}</td>
              </tr>
              <tr>
                <th>Google IP</th>
                <td>${dnsResult.address}</td>
              </tr>
            </table>
          </div>
        </body>
      </html>
    `;
    
    res.status(200).send(html);
  } catch (err) {
    console.error('Error during processing:', err);

    // Build a simple error page.
    const errorHtml = `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <title>Error</title>
          <style>
            body { font-family: Arial, sans-serif; background-color: #f7f7f7; display: flex; align-items: center; justify-content: center; height: 100vh; }
            .container { background: #fff; padding: 20px 30px; box-shadow: 0px 4px 6px rgba(0,0,0,0.1); border-radius: 8px; }
            h1 { color: #e74c3c; text-align: center; }
            p { text-align: center; }
          </style>
        </head>
        <body>
          <div class="container">
            <h1>Failed to Connect</h1>
            <p>Error: ${err.message}</p>
          </div>
        </body>
      </html>
    `;
    
    res.status(500).send(errorHtml);
  }
});

// Export the handler to be used by AWS Lambda.
module.exports.handler = serverless(app);
